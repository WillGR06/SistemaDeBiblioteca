create definer = root@localhost trigger trg_obra_bi
    before insert
    on obra
    for each row
BEGIN
  IF NEW.id_admin_cadastro IS NULL THEN
    SET NEW.id_admin_cadastro = @id_admin;
  END IF;
END;

