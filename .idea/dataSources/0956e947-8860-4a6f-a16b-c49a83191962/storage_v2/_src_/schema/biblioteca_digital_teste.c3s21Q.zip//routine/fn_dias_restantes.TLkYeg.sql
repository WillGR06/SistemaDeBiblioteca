create
    definer = root@localhost function fn_dias_restantes(p_id_emprestimo int) returns int reads sql data
BEGIN
  DECLARE v_vencimento DATETIME;
  DECLARE v_status VARCHAR(20);

  SELECT data_vencimento, status
    INTO v_vencimento, v_status
    FROM emprestimo
   WHERE id_emprestimo = p_id_emprestimo;

  IF v_status IS NULL OR v_status <> 'ativo' THEN
    RETURN 0;
  END IF;

  RETURN GREATEST(DATEDIFF(v_vencimento, NOW()), 0);
END;

