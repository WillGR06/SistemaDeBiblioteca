create definer = root@localhost trigger trg_audiobook_ad
    after delete
    on audiobook
    for each row
BEGIN
  IF @id_admin IS NOT NULL THEN
    INSERT INTO log_administracao (id_administrador, tabela_afetada, id_registro, acao, descricao)
    VALUES (@id_admin, 'audiobook', OLD.id_audiobook, 'excluir', CONCAT('Audiobook excluído (obra ', OLD.id_obra, ')'));
  END IF;
END;

