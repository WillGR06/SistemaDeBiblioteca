create definer = root@localhost trigger trg_ebook_ad
    after delete
    on ebook
    for each row
BEGIN
  IF @id_admin IS NOT NULL THEN
    INSERT INTO log_administracao (id_administrador, tabela_afetada, id_registro, acao, descricao)
    VALUES (@id_admin, 'ebook', OLD.id_ebook, 'excluir', CONCAT('E-book excluído (obra ', OLD.id_obra, ')'));
  END IF;
END;

