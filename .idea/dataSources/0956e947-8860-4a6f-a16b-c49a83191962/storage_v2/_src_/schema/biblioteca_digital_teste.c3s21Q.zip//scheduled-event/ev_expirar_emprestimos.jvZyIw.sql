create definer = root@localhost event ev_expirar_emprestimos on schedule
    every '1' HOUR
        starts '2026-11-13 00:19:49'
    enable
    do
    UPDATE emprestimo
     SET status = 'expirado',
         data_bloqueio = data_vencimento,
         data_devolucao = data_vencimento
   WHERE status = 'ativo'
     AND data_vencimento < NOW();

