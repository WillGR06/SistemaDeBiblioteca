create
    definer = root@localhost procedure sp_realizar_emprestimo(IN p_id_usuario int, IN p_id_ebook int,
                                                              IN p_id_audiobook int, IN p_forma varchar(20),
                                                              OUT p_id_emprestimo int)
BEGIN
  DECLARE v_valor DECIMAL(10,2);
  DECLARE v_ativo BOOLEAN;
  DECLARE v_repetido INT;

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  IF (p_id_ebook IS NULL) = (p_id_audiobook IS NULL) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Informe apenas um: e-book OU audiobook';
  END IF;

  SELECT ativo INTO v_ativo FROM usuario WHERE id_usuario = p_id_usuario;
  IF v_ativo IS NULL OR v_ativo = FALSE THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Usuário inexistente ou inativo';
  END IF;

  IF p_id_ebook IS NOT NULL THEN
    SELECT valor_emprestimo INTO v_valor FROM ebook WHERE id_ebook = p_id_ebook;
  ELSE
    SELECT valor_emprestimo INTO v_valor FROM audiobook WHERE id_audiobook = p_id_audiobook;
  END IF;

  IF v_valor IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Livro não encontrado';
  END IF;

  SELECT COUNT(*) INTO v_repetido
    FROM emprestimo
   WHERE id_usuario = p_id_usuario
     AND status = 'ativo'
     AND data_vencimento >= NOW()
     AND ((p_id_ebook IS NOT NULL AND id_ebook = p_id_ebook)
       OR (p_id_audiobook IS NOT NULL AND id_audiobook = p_id_audiobook));

  IF v_repetido > 0 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Você já possui um empréstimo ativo deste livro';
  END IF;

  START TRANSACTION;

  INSERT INTO emprestimo (id_usuario, id_ebook, id_audiobook, valor)
  VALUES (p_id_usuario, p_id_ebook, p_id_audiobook, v_valor);

  SET p_id_emprestimo = LAST_INSERT_ID();

  INSERT INTO pagamento (id_emprestimo, forma, status, valor)
  VALUES (p_id_emprestimo, p_forma, 'aprovado', v_valor);

  INSERT INTO acesso_digital (id_emprestimo) VALUES (p_id_emprestimo);

  COMMIT;
END;

