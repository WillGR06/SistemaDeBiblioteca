create definer = root@localhost trigger trg_obra_au
    after update
    on obra
    for each row
BEGIN
  IF @id_admin IS NOT NULL THEN
    INSERT INTO log_administracao (id_administrador, tabela_afetada, id_registro, acao, descricao)
    VALUES (@id_admin, 'obra', NEW.id_obra, 'editar', CONCAT('Obra editada: ', NEW.titulo));
  END IF;
END;

