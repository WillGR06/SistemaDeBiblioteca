create
    definer = root@localhost procedure sp_devolver_emprestimo(IN p_id_emprestimo int)
BEGIN
  DECLARE v_status VARCHAR(20);

  SELECT status INTO v_status FROM emprestimo WHERE id_emprestimo = p_id_emprestimo;

  IF v_status IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Empréstimo não encontrado';
  END IF;

  IF v_status <> 'ativo' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Este empréstimo já foi encerrado';
  END IF;

  UPDATE emprestimo
     SET status = 'devolvido',
         data_devolucao = NOW(),
         data_bloqueio = NOW()
   WHERE id_emprestimo = p_id_emprestimo;
END;

