create definer = root@localhost trigger trg_ebook_ai
    after insert
    on ebook
    for each row
BEGIN
  IF @id_admin IS NOT NULL THEN
    INSERT INTO log_administracao (id_administrador, tabela_afetada, id_registro, acao, descricao)
    VALUES (@id_admin, 'ebook', NEW.id_ebook, 'inserir', CONCAT('E-book cadastrado (obra ', NEW.id_obra, ')'));
  END IF;
END;

