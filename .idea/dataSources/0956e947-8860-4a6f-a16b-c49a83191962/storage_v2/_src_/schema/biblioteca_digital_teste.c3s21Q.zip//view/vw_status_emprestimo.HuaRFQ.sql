create definer = root@localhost view vw_status_emprestimo as
select `e`.`id_emprestimo`                                                         AS `id_emprestimo`,
       `u`.`nome`                                                                  AS `usuario`,
       coalesce(`oe`.`titulo`, `oa`.`titulo`)                                      AS `titulo`,
       (case when (`e`.`id_ebook` is not null) then 'E-book' else 'Audiobook' end) AS `tipo`,
       `e`.`data_emprestimo`                                                       AS `emprestado_em`,
       `e`.`data_vencimento`                                                       AS `data_vencimento`,
       `e`.`data_bloqueio`                                                         AS `bloqueado_em`,
       `e`.`data_devolucao`                                                        AS `data_devolucao`,
       (case
            when (`e`.`status` = 'devolvido') then 'Devolvido'
            when ((`e`.`status` = 'ativo') and (`e`.`data_vencimento` >= now())) then 'Emprestado'
            else 'Bloqueado' end)                                                  AS `situacao`
from (((((`biblioteca_digital_teste`.`emprestimo` `e` join `biblioteca_digital_teste`.`usuario` `u`
          on ((`u`.`id_usuario` = `e`.`id_usuario`))) left join `biblioteca_digital_teste`.`ebook` `eb`
         on ((`eb`.`id_ebook` = `e`.`id_ebook`))) left join `biblioteca_digital_teste`.`obra` `oe`
        on ((`oe`.`id_obra` = `eb`.`id_obra`))) left join `biblioteca_digital_teste`.`audiobook` `ab`
       on ((`ab`.`id_audiobook` = `e`.`id_audiobook`))) left join `biblioteca_digital_teste`.`obra` `oa`
      on ((`oa`.`id_obra` = `ab`.`id_obra`)));

