create definer = root@localhost trigger trg_audiobook_au
    after update
    on audiobook
    for each row
BEGIN
  IF @id_admin IS NOT NULL THEN
    INSERT INTO log_administracao (id_administrador, tabela_afetada, id_registro, acao, descricao)
    VALUES (@id_admin, 'audiobook', NEW.id_audiobook, 'editar', CONCAT('Audiobook editado (obra ', NEW.id_obra, ')'));
  END IF;
END;

