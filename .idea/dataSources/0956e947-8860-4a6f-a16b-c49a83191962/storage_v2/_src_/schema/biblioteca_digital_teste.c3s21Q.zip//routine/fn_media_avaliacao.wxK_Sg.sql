create
    definer = root@localhost function fn_media_avaliacao(p_id_obra int) returns decimal(3, 2) reads sql data
BEGIN
  DECLARE v_media DECIMAL(3,2);

  SELECT COALESCE(AVG(nota), 0)
    INTO v_media
    FROM avaliacao
   WHERE id_obra = p_id_obra;

  RETURN v_media;
END;

