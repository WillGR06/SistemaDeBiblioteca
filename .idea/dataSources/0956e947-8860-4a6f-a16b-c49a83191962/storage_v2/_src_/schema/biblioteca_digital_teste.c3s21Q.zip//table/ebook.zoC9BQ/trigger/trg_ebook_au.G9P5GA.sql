create definer = root@localhost trigger trg_ebook_au
    after update
    on ebook
    for each row
BEGIN
  IF @id_admin IS NOT NULL THEN
    INSERT INTO log_administracao (id_administrador, tabela_afetada, id_registro, acao, descricao)
    VALUES (@id_admin, 'ebook', NEW.id_ebook, 'editar', CONCAT('E-book editado (obra ', NEW.id_obra, ')'));
  END IF;
END;

