create definer = root@localhost trigger trg_ebook_valor_bi
    before insert
    on ebook
    for each row
BEGIN
  IF NEW.valor_emprestimo < 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Valor de empréstimo não pode ser negativo';
  END IF;
END;

