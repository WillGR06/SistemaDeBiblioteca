create definer = root@localhost trigger trg_emprestimo_bi
    before insert
    on emprestimo
    for each row
BEGIN
  SET NEW.data_vencimento = DATE_ADD(NOW(), INTERVAL 30 DAY);
  SET NEW.status = 'ativo';
END;

