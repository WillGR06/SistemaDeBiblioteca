create definer = root@localhost trigger trg_obra_ad
    after delete
    on obra
    for each row
BEGIN
  IF @id_admin IS NOT NULL THEN
    INSERT INTO log_administracao (id_administrador, tabela_afetada, id_registro, acao, descricao)
    VALUES (@id_admin, 'obra', OLD.id_obra, 'excluir', CONCAT('Obra excluída: ', OLD.titulo));
  END IF;
END;

